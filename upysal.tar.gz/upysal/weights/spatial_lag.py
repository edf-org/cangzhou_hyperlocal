"""
spatial lag operations
"""
__all__ = ['lag_spatial']


def lag_spatial(w, y):
    """
    Spatial lag operator. If w is row standardized, returns the average of
    each observation's neighbors; if not, returns the weighted sum of each
    observation's neighbors.

    Parameters
    ----------

    w : W
        weights object
    y : array
        numpy array with dimensionality conforming to w (see examples)

    Returns
    -------

    wy : array
         array of numeric values for the spatial lag

    """
    return w.sparse * y
